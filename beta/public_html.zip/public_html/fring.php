<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Have fun using Fring calls speaking to your dear ones abroad</title>
<meta name="keywords" content="Fring Call, Fring"/>
<meta name="description" content="Fring makes it easier for the people to call, who have their near & dear ones staying overseas. Fring calls cuts off telephone bills marginally & let you speak."/>
<?php include_once('includes/head.php')?>
</head>
<body>
<style>html{background:none;}</style>
<?php include_once('includes/header.php')?>

<!--heading-->
<h1 class="heading topHeader pdT3">Fring Calls</h1>

<!--MainContainer-->
<div id="mainContainer">
	<div class="container pdT4">
      
          <ul id="indul" class="ln">
                <li>
                      <div class="fl wid500">
                        <h4>Fring is fun!</h4>
                        <p><b><i>Fring</i></b> is one of the ace software providing VoIP technology for international calling. VoIP technology facilitates phone calls at low call rates as compared to PSTN connections because of 
the involvement of technology in it. It gives you the mobility to speak on phone when in transit 
and that is the real fun, isn't it? The best thing about Fring is its user interface. It provides a very 
simple UI so that anyone can use it.</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
                <li>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                      <div class="fl wid500">
                        <h4>Fring call procedure </h4>
                        <p>Calling from Fring is a cake walk. You just need to download it, select the option of sip call, from the given options select others and click 'ok'. You are successfully registered after this! 
All that you need to do now is just type in your user ID (alphanumeric ID you chose at the time 
of signup) and password (the one you use to login your phone91 account). Now enjoy calling 
anywhere in the world!</p>
                      </div>
                </li>
                
                <li>
                      <div class="fl wid500">
                        <h4>Appliance</h4>
                        <p>The easy signup opens the doorway of calling for you. You have an address book at your hand which helps you remember all the names that expect your call! You can select any name you 
wish to call from there and just choose the option of sip call to call! Enjoy the hassle free chitchat at very low rates that you always wished for. Fring is like a dream come true for many 
hearts distant by geography!</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
                <li>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                      <div class="fl wid500">
                        <h4>For international calling</h4>
                        <p>Looking for calling overseas? Fring just best suits you! There are so many IP dialers available in the market for international calling but Fring tops all. This can happen only when the quality 
of the calls is good with comparative rates. The ease of use that Fring provides is unmatchable. 
Phone 91 has its own dialer as well but even if you use Fring you won't be disappointed for sure!</p>
                      </div>
                </li>
                
                <li>
                      <div class="fl wid500">
                        <h4>Compatibility</h4>
                        <p>To make a VoIP call you need an IP dialer. Fring call is an IP dialer which supports all the communication services such as Skype, Gtalk, MSN, ICQ, etc. It is easily downloadable on 
any mobile handset for application. It supports all kinds of operating software which makes it 
compatible for Android devices like Iphone also. Fring supports 2G, 3G and all kinds of internet 
connections as well. In short Fring is super flexible!</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
          </ul>
      
      
      </div>
</div>
<!--//MainContainer--> 

<?php include_once('includes/footer.php')?>

</body>
</html>
