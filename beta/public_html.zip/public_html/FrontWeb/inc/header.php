<?php
$uri = $_SERVER['REQUEST_URI'];
$page = explode("/", $uri);
$page = $page[count($page)];
echo $page;
?>
<!--Header-->
<div class="header">
    <div class="inner">
        <a href="index.php" title="Phone91" id="logo" class="ic-logo"></a>
        <div class="nav fr">
      		  	<a href="index.php" title="Home"><span>Home</span></a>
                <a href="about.php" title="About"><span>About</span></a>
                <a href="features.php" title="Features"><span>Features</span></a>
                <a href="#get-started" title="Get Started"><span>Get Started</span></a>
                <a href="pricing.php" title="Pricing"><span>Pricing</span></a>
                <a href="start-up.php" title="Start up"><span>Start up</span></a>
                <a href="support.php" title="Support"><span>Support</span></a>
                <button title="My account" class="btn btn-primary btn-medium fl myAc"><span>My account</span></button>
        </div>
    </div>
</div>
<!--//Header-->