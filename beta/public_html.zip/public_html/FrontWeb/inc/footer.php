<!--TopFooter-->
<div class="topFooter clear">
	<div class="inner alC">
    		<div class="h3 ligt">Be Social</div>
            <div class="h4 ligt">Become a friend, we will stay in touch forever</div>
           	<p class="socialLinks mT20">
                    <a href="javascript:void(0)" title="Facebook"><span class="ic-fbic social"></span></a>
                    <a href="javascript:void(0)" title="Twitter"><span class="ic-twic social"></span></a>
                    <a href="javascript:void(0)" title="Linkedin"><span class="ic-inic social"></span></a>
                    <a href="javascript:void(0)" title="Gmail"><span class="ic-gmic social"></span></a>
            </p>
    </div>
    </div>
<!--TopFooter-->

<!--Footer-->
    <div class="footer clear">
   		 <div class="inner foterMain">
         		<ul class="box fb1stbox">
                	<li class="head">Lets talk</li>
                    <li><a href="support.php" title="Support">Support</a></li>
                    <li><a href="faq.php" title="FAQ's">FAQ's</a></li>
                </ul>
                <ul class="box">
                	<li class="head">Explore</li>
                	<li><a href="about.php" title="About">About</a>
                     <li><a href="features.php" title="Features">Features</a></li>
                    <li><a href="terms.php" title="Terms of use">Terms of use</a></li>
                    <li><a href="privacy.php" title="Privacy policy">Privacy policy</a></li>
                </ul>
                
                <ul class="box fb3rd">
                	<li class="head">From our blog</li>  
                     <li>Title1 of Blog Title1 of Blog
                     <li>Title1 of Blog Title1 of Blog</li>
                     <li>Title1 of Blog Title1 of Blog</li>
               </ul>
               
                 <ul class="box">
                	<li class="head">Contact info</li>
                    <li><span class="ic-email mR10"></span>support@phone91.com</li>
                    <li><span class="ic-contact"></span>19101-2020</li>
                </ul>
         </div>
    </div>
<!--//Footer-->

<!--BottomFooter-->
<div class="btmFooter clear">
		<div class="inner alC">
        		PHONE 91 © 2013-2014 | All Rights Reserved
		</div>
</div>
<!--BottomFooter-->

