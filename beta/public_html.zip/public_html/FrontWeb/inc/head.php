<!--<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>-->
<link type="text/css" rel="stylesheet" href="css/style.css" />

<script type="text/javascript" src="/js/jquery-1.9.1.js"></script> 
<script type="text/javascript" src="/js/jquery.form.js"></script> 
<script type="text/javascript" src="/js/sign_up.js"></script>
<script type="text/javascript" src="js/scrolltopcontrol.js"></script>