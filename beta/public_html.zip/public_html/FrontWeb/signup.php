<?php
function countryArray() {
        $url = "http://voip92.com/isoData.php";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($ch);
        curl_close($ch);

        $string1 = json_decode($data, true);
        for ($i = 0; $i < count($string1); $i++) {
            $country[$string1[$i]['CountryCode']] = $string1[$i]['Country'];
        }
        return $country;
}
    
$country = countryArray();

function getCurrencyList() {
    $url = "https://voip91.com/currency/currencyList.php";
    $ch = curl_init();    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

$currencyList = json_decode(getCurrencyList());



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Phone91 | Sign up</title>
</head>
<body>
<!--Main Wrapper-->
<div class="warpper">
<?php include_once("inc/head.php");?>
  <!--Inner Page Head-->
  <div class="innerPageBnr oh clear contact">
    <div class="inner">
 	   <div class="loginFrm">
            <div class="leftFrm fl">
                    <div class="subHead">Existing Users <span>Sign in</span></div>
                    <form action="" method="">
                         <div class="fields">
                                <p><span class="ic-user"></span></p>
                                <input type="text" class="" name="uname" placeholder="Username/Email ID"/>
                         </div>
                         <div class="fields">
                                <p><span class="ic-pass"></span></p>
                                <input type="text" class="" name="password" placeholder="Password"/>
                                <span class="whTClr alR fr fS13">Forgot your password?</span>
                         </div>
                       
                        <div class="oh clear signed">
                            <input type="submit" title="Sign in" value="Sign in" class="btn btn-medium  btn-info fl" />
                            <div class="fr stay">
                                    <input type="checkbox"/><span class="gray fS12">Stay signed in</span></div>
                        </div>
            		</form>
           	</div>
            <div class="midBorder fl"></div>
           	<div class="rightFrm fl">
                <button title="Sign in with Gmail " class="btn btn-medium btn gm fullWid">Sign in with Gmail </button>
                <br />
                <button title="Sign in with Facebook" class="btn btn-medium btn fb mT20 fullWid">Sign in with Facebook </button>
            </div>
        </div>
    </div>
  </div>
  <!--//Inner Page Head--> 
  
  <!--Inner Page Content-->
  <div class="innerContent  clear">
        <div class="inner SignUpform">
        	<div class="frmHead">The best way to share your feelings with Phone 91 <span class="ligt">Create a free account by Signing Up</span></div>
            
            <div class="innerFrmSpc">
                    <div class="leftBorder">
                      <form name="signup" class="signup cmnFrm" id="signup" onSubmit="return validate();" method="post" action="http://phone.phone91.com/action_layer.php?action=signupP91">
                            <div class="fields">
                                  <label>Your full name</label>
                                  <input type="text"/>
                            </div>
                            
                             <div class="fields">
                             		 <label>Sign up as</label>
                                     <p class="signAs">
                                            <input type="radio" name="user" checked />
                                            <span>User</span> &nbsp; 
                                            <input type="radio"name="user" />
                                            <span>Reseller</span>
                                   </p>
                            </div>
                            
                            <!--<div class="fields">
                                  <label>Sign up as</label>
                                  <select name="client_type" id="client_type" >
                                    <option value="3" selected>User</option>
                                    <option value="2">Reseller</option>
                                </select>
                            </div>-->
                            
                            <div class="fields">
                                  <label>Select your country</label>
                                  <select tabindex="1"  name="location" id="location" >
                                        <?php 
                                        foreach($country as $key =>$countryNames){                
                                        echo "<option value='$key'>$countryNames</option>";
                                        }?>    
                                 </select>
                            </div>
                            
                            <div class="fields">
                              <label>Choose your currency</label>
                              <select name="currency" id="currency">   
                                        <?php                       
                                        foreach ($currencyList as $key => $value) {
                                        echo '<option value="'.$value->currencyId.'" >'.$value->currency.'</option>';
                                        }
                                           ?>
                                        </select>
                            </div>
                            
                            <div class="fields">
                                  <label>Your phone number</label>
                                    <input name='code' type="text" id="code" onKeyUp="selectOption($(this).val())" class="min"  />
                                        <input type="text" name='mobileNumber' id='mobileNumber' class="max" />
                                        <div id="moberror"></div>
                            </div>  
                            <div class="fields">
                                  <label>Choose your username</label>
                                 <input name="username" id="username" type="text"  onblur="check_user_exist(); return false;" onKeyUp="check_user_exist()" value="<?php echo $_REQUEST['username'];?>"/>
                                       <div class="msg "></div>
                            </div>
                            <div class="fields">
                              <label>Email ID</label>
                              <input type="text" name='email' id='email' onKeyUp="check_email_exist()" value="<?php echo $_REQUEST['email'];?>"/>
                                        <div class="msg "></div>
                            </div>
                            <div class="fields">
                              <label>Password</label>
                              <input type="password" name='password' id='password' value="<?php echo $_REQUEST['password'];?>" />
                                       <span class="clr"></span>
                            </div>
                            <div class="fields">
                              <label>Re-enter password</label>
                             <input type="password" name='repassword' id='repassword' value="<?php echo $_REQUEST['password'];?>" />
                                       <span class="clr"></span>
                            </div>
                            
                            <input type="hidden" name="domain" id="domain" value="<?php echo "http://".$_SERVER['HTTP_HOST'];?>"/> 
                            <div class="fields">
                                  <label>&nbsp;</label>
                                  <input type="submit" id="signupSubmit" title="Submit" value="Submit" class="btn btn-medium btn-info" onFocus="this.blur();"/>
                            </div>
              </form>
                    </div>
                    <div class="signupBorder">
                    	<span class="ic-or"></span>
                    </div>
                    <div class="rightSpce">
                                <div><span class="ic-char1 db clear"></span> </div> <br />
                                <button title="Sign in with Gmail " class="btn btn-medium btn gm fullWid mT20">Sign in with Gmail </button>
                                <br />
                                <button title="Sign in with Facebook" class="btn btn-medium btn fb mT20 fullWid">Sign in with Facebook </button>
                    </div>
              </div>
        </div>
  </div>
  <!--//Inner Page Content-->
  
<?php include_once('inc/footer.php')?>
<script type="text/javascript">
function showDiv(){
var val = window.location.hash.substring(1);
console.log(val);

	$('html,body').animate({scrollTop: $("#logo").offset().top-140},'slow');
	$('.cmndiv').hide();
	$('#rightCnt #'+val).show();
	//$('.anibtn').removeClass('active');
	//$('.'+val).addClass('active');

}


//$(document).ready(function() { 
//              var options = { 
//                      dataType: 'jsonp',
//                      type:'POST',
//                      beforeSubmit: validate,
//                      success: showResponse  // post-submit callback 
//              }; 
//              $('#signup').ajaxForm(options); 
//      });      

$("#location").on('change',function(event){
$("#code").val($(this).val().replace(/ /g,''));

})

function selectOption(valu)
{
$('#location option[value="'+valu+'"]').prop('selected',true);
}

</script>
</div>
<!--//Main Wrapper-->
</body>
</html>
