<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Phone91 | Features</title>
<link type="text/css" rel="stylesheet" href="css/style.css" />
</head>
<body>
<!--Main Wrapper-->
<div class="warpper">
<?php include_once("inc/head.php");?>
  <!--Inner Page Head-->
  <div class="innerPageBnr oh clear featureBanner">
    <div class="inner">
            <div class="bannerSecSn">
            	<img src="images/dummy.png" width="150" height="143" class="fl top"/>
                <div class="fl slogans">
                        <h1 class="ligt">They come in a bundle of joy!</h1>
                        <p class="para">There's a lot more to Phone 91 than unlimited international calling and quick call management options. Well, explore on your own!</p>
                        <button class="btn btn-medium btn-info" title="Sign in Or Sign up">Sign in Or Sign up</button>
                </div> 
        </div>
    </div>
  </div>
  <!--//Inner Page Head--> 
  
   <!--Gray Patch Wrapper-->
  <div class="grayPatch featur">
  			<div class="inner">
                        <div class="featureTop clear">
                        		<div class="box">
                                		<span class="ic-userc"></span>
                                      	<div class="midHead ligt">User</div>
                                        <p>
                                        		Staying connected through two-way calling and Phone 91's own mobile dialer couldn't have been easier. 
                                                You get to recall on the go and manage your entire call history.
                                        </p>
                                </div>
                                
                                <div  class="box">
                                	  <span class="ic-admin"></span>	
                                      <div class="midHead ligt">Admin</div>
                                      Go global by adding clients in various countries and managing them at ease through PIN addition, 
                                            SIP calling, white label solution and other interesting options. 
                                      <div>Reseller</div>
                                </div>
                                
                                <div  class="box">
                                		<span class="ic-reseller"></span>	
                                         <div  class="midHead ligt">Reseller</div>
                                		<p>There's a lot more you can do with Admin panel on rent feature. You can have acces to multiple admin,
                                         route management and dialplan management options. 
                                        </p>
                                </div>
                        </div>
            </div>  
  	</div>
  </div>
   <!--//Gray Patch Wrapper-->
  
  
  <!--Inner Page Content-->
  <div class="innerContent">
       <div class="inner">
               <div class="takLook alC takLook">
             		<span>Want to explore?</span>
              	 <button class="btn btn-medium btn-info" title="Take a look">Move in</button>
             </div>
       </div>      
  </div>
  <!--//Inner Page Content-->


   <!--Users Features-->
    <div class="lightGray">
        	<div class="inner">
                <div class="shadedHead alC ligt fS25 needToknw">All you <span>need to know</span> about start calling </div>
            		
            	<div class="midFeature">
               		<div class="cateGryHead"> User</div>      
                              
                	<span class="ic-banner fl db"></span>
                    <ul>
                    	<li>
                        	<div>Unlimited international calling</div>	
                            <p>Go global by adding clients in various countries and managing them at ease through PIN addition, SIP calling, white label solution 
                            and other interesting options. </p>
                        </li>
                        
                        
                        <li>
                        	<div>Unlimited international calling</div>	
                            <p>Go global by adding clients in various countries and managing them at ease through PIN addition, SIP calling, white label solution 
                            and other interesting options. </p>
                        </li>
                        
                        
                        <li>
                        	<div>Unlimited international calling</div>	
                            <p>Go global by adding clients in various countries and managing them at ease through PIN addition, SIP calling, white label solution 
                            and other interesting options. </p>
                        </li>
                        
                        
                        <li>
                        	<div>Unlimited international calling</div>	
                            <p>Go global by adding clients in various countries and managing them at ease through PIN addition, SIP calling, white label solution 
                            and other interesting options. </p>
                        </li>
                        
                        <li>
                        	<div>Unlimited international calling</div>	
                            <p>Go global by adding clients in various countries and managing them at ease through PIN addition, SIP calling, white label solution 
                            and other interesting options. </p>
                        </li>
                    </ul>
                </div>        
                    
            
            </div>
    </div>
  <!--//Users Features-->
  
  <!--admin Features-->
	<div class="lightBlue">
    		<div class="inner"></div>
    </div>
  <!--//admin Features-->
  
  
  <!--Reseller Features-->
    <div class="lightGray">
        <div class="inner"></div>	
    </div>
   <!--//Reseller Features-->
  
<div class="inner">
  		<p class="makeBtr alC">Scratching head? Our <a href="#">FAQ's</a> will help to make you understand even better. </p>
You can also check <a href="#">support</a> for detailed queries. 
</div>
  
  <?php include_once('inc/footer.php')?>
</div>
<!--//Main Wrapper-->
</body>
</html>
