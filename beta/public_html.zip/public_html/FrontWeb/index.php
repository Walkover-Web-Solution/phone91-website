<?php
function getCurrencyList() {
    $url = "https://voip91.com/currency/currencyList.php";
    $ch = curl_init();    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
$currencyList = json_decode(getCurrencyList());
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Phone91 | Pc to phone calling | Internet to phone call</title>
<?php include_once('inc/head.php')?>
</head>
<body class="no-touch">
<!--Main Wrapper-->
<div class="warpper">
	<?php include_once('inc/header.php')?>
    <!--Banner-->
    <div class="banner clear">
    	<div class="inner">
        		
                <div class="leftBaner">
                	<p class="ligt only whTClr">Only a few people can excite your spirit.<br>Do not miss them!</p>
                	<span class="ic-banner"></span>
                	<div class="slogan">
						<p class="how ligt">
                           <a title="See" class="btn btn-large btn-danger cp db" href="https://voip91.com/voipcall/pricing.php"><span>See</span></a>
                           <span>how little it costs to call</span>
                    </p></div>
                </div>
                
                <div class="rightSide">
                    		<div class="h2">Sign in</div>
                            <form action="http://phone.phone91.com/action_layer.php?action=loginRedirect" method="POST" name="login">				  
                            <!--http://phone.phone91.com/action_layer.php?action=loginRedirect-->

                            <div class="fields oh clear">
                                <input type="text" name="uname" placeholder="Username"
                                onfocus="(this.value == 'Username') && (this.value = '')"
                                onblur="(this.value == '') && (this.value = 'Username')" id="" class="isInput153 fl" value=""/>
                            	
                                <input type="password" name="pwd" placeholder="Password"
                                onfocus="(this.value == 'Passaword') && (this.value = '')"
                                onblur="(this.value == '') && (this.value = 'Passaword')" id="" class="isInput153 fl"/>
                                <input type="hidden" name="domain" id="domain" value="<?php echo "http://".$_SERVER['HTTP_HOST']."/FrontWeb";?>"/>
                                <!--<input type="submit" title="Sign In" name="submit" id="" class="btn btn-danger btn-mini fl"/>  -->
                                <button class="btn btn-danger btn-mini fl" title="Sign in"  type="submit" name="submit">
                               		<span class="ic-signin"></span>
                                </button>
                            </div>
                            </form>
                            <a href="javascript:void(0)" title="Forgot your password" class="passWrd alR">Forgot your password?</a>
                            <div class="title">
                            	or sign in  with 
                                <a href="javascript:void(0)"  title="Facebook">Facebook</a> | 
                                <a href="javascript:void(0)" title="Google">Google</a>
                            </div>
                            
                            <div class="h2">Sign Up with</div>
                            <div class="socialSignin">
                            <a href="javascript:void(0)" title="Facebook" class="fb"><span class="ic-fb"></span></a>
                            <a href="javascript:void(0)" title="Gmail" class="gm"><span class="ic-gm"></span></a>
                            </div>
              			    <form method="POST" action="signup.php" id="signupForm" onsubmit="return register();">   
                              <div class="or">
                            	<span class="or ligt">Or</span>
                                
                                  <div class="fieldR">
                                  	<input type="text" id="username" name="username" value="" onblur="check_user_exist()"  placeholder="First Name" />
                                 <div class="msg"></div>
                                 </div>
                                 
                                  <div class="fieldR">
                                  <input type="password" id="password"  name="password" value="" placeholder="Password" onblur="check_password_strength();"/>
                                 <div class="msg"></div>
                                 </div>
                                 
                                <div class="fieldR">
                                     <input type="text" id="email" value="" name="email" placeholder="Email" onblur="check_email_exist()"/>
                                     <div class="msg"></div>
                                </div>
                                
                                <input type="submit" title="Get Started and Create My Account" value="Get Started and Create My Account" name="submit" class="btn btn-danger btn-large isInput100 get" />
                                
                                <!--<a href="signup.php" title="Get Started and Create My Account" class="btn btn-danger btn-large isInput100 get">Get Started and Create My Account</a>-->
                                <p class="terms">By signing up, you agree to the 
                                <a href="https://voip91.com/voipcall/terms.php" class="blackClr" title="Terms of Use">Terms of Use</a> and
                                 <a href="https://voip91.com/voipcall/privacy.php" class="blackClr" title="Privacy Policy">Privacy Policy</a></p>
                            </div>
                    		</form>
                </div>
        </div>
    </div>
    <!--//Banner-->
    
    <!--Content-->
    <div class="content">
    	<div class="inner">
        	
        	<h1 class="alC ligt">
                <span class="ic-animate"></span>
                There's something for <span>you!</span></h1>
            <div class="row clear">
            	<div class="thumbnil">
                	<div class="head ligt">Bring bonds to life</div>
                	<div class="info">
                    	  <p class="clear ligt">
                          	Listen to the voice of your loved ones with quick options like two-way calling straight from your desktop/mobile and easy to go apps like Vtok and Phone 91's own mobile dialer.  <a href="javascript:void(0)" title="Get to know">Get to know.</a></p>
                            <span class="ic-char1"></span>
                    </div>
                </div>
                <div class="thumbnil">
                	<div class="head ligt">Interesting stuff for you</div>
                	<div class="info">
                    	 <p class="clear ligt">Discover much more by toying with a variety of features like managing your call and transaction log, view recent call history, recall and sync contacts option.  <a href="javascript:void(0)" title="Get to know">Get to know.</a></p>
                         <span class="ic-char2"></span>
                    </div>
                </div>
                <div class="thumbnil">
                	<div class="head ligt">Be a start-up	</div>
                	<div class="info">
                    		 <p class="clear ligt"> 
                             Call yourself a proud start-up by becoming a Reseller or by getting our Admin panel on rent. Add plans and PIN's for your own clients, manage routes, and use Call Shop.  <a href="javascript:void(0)" title="Get to know">Get to know.</a>
                           </p> 
                           <span class="ic-char3"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--//Content-->
    <?php include_once('inc/footer.php')?>
    </div>
 <!--Main Wrapper-->
</body>
</html>