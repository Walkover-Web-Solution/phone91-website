<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Phone91 | About us</title>
<?php include_once("inc/head.php");?>
</head>
<body>
<!--Main Wrapper-->
<div class="warpper">
<?php include_once("inc/header.php");?>
  <!--Inner Page Head-->
  <div class="innerPageBnr oh clear">
    <div class="inner">
            <div class="bannerSecSn">
            	<img src="images/dummy.png" width="150" height="143" class="fl top"/>
                <div class="fl slogans">
                        <h1 class="ligt">There's a call behind every care!</h1>
                        <p class="para">Listen to the voice of your loved ones with easy to go apps like Gtalk, Vtok for Iphone, and Phone 91's own mobile dialer.</p>
                        <button class="btn btn-medium btn-info" title="Sign in Or Sign up">Sign in Or Sign up</button>
                </div> 
        </div>
    </div>
  </div>
  <!--//Inner Page Head--> 
  
   <!--Gray Patch Wrapper-->
  <div class="grayPatch">
  			<div class="inner">
            		<div class="shadedHead alC ligt"><span>What</span> Phone 91 does?</div>
                   <div class="about"> 
                      	   <ul class="colLft fl">
                                <li class="head"><span class="ic-fRuser "></span>For Users: </li>
                                <li> Unlimited international calling at lowest rates.</li>
                                <li> An option to recall, manage recent call history and view the entire transaction log.</li>
                                <li> Sync contacts, and much more.</li>
                           </ul>
                           <ul class="colRight">
                                <li class="head bottom"><span class="ic-fRadmin"></span>For Reseller/Admin:</li>
                                <li>Manage clients - view clients recent call history, active call log, etc.</li>
                                <li>Manage routes.</li>
                                <li>Add routes (for admin).</li>
                                <li>Add PIN's.</li>
                                <li>Call shop.</li>
                           </ul>
                    </div>
                   	<button title="Pricing" class="btn btn-medium btn-radius cntrBtn">Pricing</button>
            </div>  
  	</div>
  </div>
   <!--//Gray Patch Wrapper-->
  
  
  <!--Inner Page Content-->
  <div class="innerContent  clear">
       <div class="inner">
            	<div class="shadedHead alC ligt"><span>Get</span> Started</div>
                <div class="shadeSubHead alC ligt gray">All you need to make a call</div>
                
                <div class="started clear oh">
                        <div class="box alC">
                                <p class="circle"><span class="ic-dskTop"></span></p>
                                <div class="fHead">Desktop or Mobile</div>
                                <p class="fS15">A personal computer with basic configuration or a smart-phone is all you need to start making calls. </p></div>
                        
                        <div class="box alC">
                               <p class="circle"> <span class="ic-intrNet"></span></p>
                                 <div class="fHead">Internet connection</div>
                                <p class="fS15">A 2G or 3G internet connection enabled in your PC/Mobile is good enough to enjoy high-quality voice calls.</p>
                        </div>
                        
                        <div class="box alC">
                                <p class="circle"><span class="ic-mic"></span></p>
                                 <div class="fHead">Headphone or mic</div>	
                                <p class="fS15">You are definitely going to need them if you are using Phone 91 on your personal computer.</p>
                        </div>
                </div>
               <button title="Download" class="btn btn-medium btn-radius cntrBtn"><span class="ic-down"></span>Download</button>
               
               <div class="tryIt clear oh">
              		 <div class="shadedHead alC ligt"><span>Try</span> it</div>
               		<div class="tryItCont clear oh">
                            <div class="block">
                                    Make a two-way call
                           </div>
                           <div class="block">
                                    Phone 91 mobile dialer	
                           </div>
                    </div>	
      		 </div>
             
             <div class="takLook alC">
             		<span>There's more to it.</span>
              	 <button title="Take a look" class="btn btn-medium btn-info">Take a look</button>
             </div>
             
             
  </div>
  <!--//Inner Page Content-->

<?php include_once('inc/footer.php')?>
</div>
<!--//Main Wrapper-->
</body>
</html>
