<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Phone91 | Thank you</title>
<link type="text/css" rel="stylesheet" href="css/style.css" />
</head>
<body>
<!--Main Wrapper-->
<div class="warpper">
<?php include_once("inc/head.php");?>
  <!--Inner Page Head-->
  <div class="innerPageBnr oh clear">
    <div class="inner">
            <div class="bannerSecSn">
            	<img src="images/dummy.png" width="150" height="143" class="fl top"/>
                <div class="fl slogans thank">
                        <h1 class="ligt">Thank you for Signing Up with Phone 91</h1>
                </div> 
        </div>
    </div>
  </div>
  <!--//Inner Page Head--> 
  
   
  <!--Inner Page Content-->
  <div class="innerContent  clear padd">
       <div class="inner">
            <div class="shadedHead alC ligt fS25">Please follow the below steps to <span>start calling</span> </div>
                    <div class="steps">
                    		<a href="javascript:void(0)" class="ligt">
                            	<span class="ic-dnone"></span>
                          		Verify Mobile Number
                            </a>
                            <a href="javascript:void(0)" class="ligt">
                                <span class="ic-chk"></span>
                                Verify Email ID
                            </a>
                   			<a href="javascript:void(0)" class="ligt">
                            	<span class="ic-three"></span>
                                Ready to call
                          </a>
                   </div>

                  <!-- Step One Content-->
                   <div class="thankuCont">
                   		<div class="subTanku">
                            <div class="clear oh">
                              <label>Enter verification code</label>
                                    <input type="text"/>
                              <input type="submit" title="Verify" value="Verify" class="btn btn-medium btn-info"/>
                            </div>
                            <div class="detail">
                                <p>We have sent a verification code on your mobile number 99XXXXXXXX. </br> If you haven't receive the verification code yet, 
                                    we can resend the code via <a href="#">call</a> or <a href="#">SMS</a>.
                                </p>
                           </div>
                            <p class="bPra">In case you have entered a wrong mobile number, you can change it by using <a href="#">change</a> option.</p>
                                
                         <!--Message Succes/Error-->
                                      <!--  <p class="cooret">
                                                <span class="ic-right"></span>
                                                Successfully verified Email ID!
                                        </p>
                
                                        <p class="wrng">
                                                <span class="ic-wrng"></span>
                                                Verification failed.
                                        </p>-->
                          <!--//Message Succes/Error-->
                      
                      
       				 </div>
                     </div>
                  <!-- //Step One Content-->
                  
                  <!-- Step Two Content-->
                   <!--<div class="thankuCont">
               		 <div class="subTanku">
                                <div class="clear oh">
                                  <label>Enter verification code</label>
                                        <input type="text"/>
                                  <input type="submit" title="Verify" value="Verify" class="btn btn-medium btn-info"/>
                                </div>
                                
                       		<div class="detail moreDetail">
           	   					  <p>Verify your Email ID by entering the verification code/by clicking on the verification link we have sent on your Email ID.</p>
                                    
                                    <p>In case you haven't receive the verification code/verification link yet, you can <a href="#">request</a> another one.</p>
                                    
                                 <p>You can also change your Email ID by using the <a href="#">change</a> option.</p>
                   		   </div>
       				 </div>
                  </div>-->
                  <!-- //Step Two Content-->
                  
                  <!-- Step Three Content-->
                   <!--<div class="thankuCont">
               		 <div class="subTanku">
                                <div class="clear oh">
                                  <label class="alC">You are all set to make your first call</label>
                                </div>
                       		<div class="detail centerDone">
           	   					 <p>We have added a little fund in your Phone 91 account so that you can start calling. You can use the buy option on the top 
                                 right-most side of your Phone 91 account to add more funds.</p>
                   		   </div>
                           <div class="hpy ligt">
                           		<p>Happy Sharing!</p>
                                <span class="ic-smily"></span>
                           </div>
       				 </div>
                    </div>  -->
                  <!-- //Step Three Content-->
                  
         </div>
  </div>
  <!--//Inner Page Content-->

<?php include_once('inc/footer.php')?>
</div>
<!--//Main Wrapper-->
</body>
</html>
