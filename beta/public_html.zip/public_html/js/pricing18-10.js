
function searchPrice(){
   
    var term = $("#search").val();
    if(term == '' || term == null){
	    $('#stcnt').show();						
	    $('#internationalCall').html('');	
    }
    var currency = $("#currency").val();
	$.ajax({
			type: "GET",
                        dataType: 'jsonp',
			url: "https://voip91.com/searchRate.php",
			data: "action=loadDetails&term="+term+"&currency="+currency,
			success: function(data){
                            
                              $.each( data, function(key, item ) {
//                                alert(key +" = "+ item);  
                              })

			}                 
		});
		


}

function searchByCountry(val){
    $.ajax({
	    type: "GET",
	    url: "/searchRate.php",
	    data: "action=loadDetails&term="+val,
	    success: function(data){
		    var flag;

		    for(i in cobj)
		    {
			    if($.trim(cobj[i].country).toLowerCase() == val)
			    {
				    flag = cobj[i].iso2.toLowerCase();
			    }							
		    }

		    var rates = $.parseJSON('{"rates":'+data+',"flag":"'+flag+'","country":"'+val+'"}');
		    $('#stcnt').hide();
		    jd({tmpl:'#rate',obj:rates},function(html){							
			    $('#internationalCall').html(html);	
		    });
	    }                 
    });
}



