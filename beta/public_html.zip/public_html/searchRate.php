<?php 

$isDetail = 0;
if(isset($_REQUEST["action"]) && $_REQUEST["action"]=="loadDetails")
    $isDetail=1;
if(isset($_GET["term"]))
{
	$cntry=0;
	$cntry = strtolower($_GET["term"]);
	$reg_ex = '/^0+[1-9]*/';
	if(preg_match($reg_ex,$cntry))								
	$mobile_no[$i]= preg_replace('/0*/','',$mobile_no[$i],1);
	
	if (!$cntry) return;
	
        $dbh = mysqli_connect('localhost', 'voip91_switch', 'yHqbaw4zRWrUWtp8', 'voip91_switch') or die("Couldnot connect to the server" . mysqli_connect_error());
        
             
	$search_qry;
	if(isset($_SESSION['id_tariff']) && ($_SESSION['id_tariff']==8 || $_SESSION['id_tariff']==9 || $_SESSION['id_tariff']==7))
	{
		$cur=$_SESSION['id_tariff'];	
		if(!is_numeric($cntry))
		{
			$search_qry="select distinct countryName,prefix,voiceRate,operator from 91_tariffs where countryName like '".$cntry."%' and tariffId like '".$cur."' ";
			
		}
		else
		{
		    $len_max=5;
		    $search_qry="select distinct countryName,prefix,voiceRate,operator from 91_tariffs where tariffId like '".$cur."' and ( ";
		    for ($exts_i = $len_max; $exts_i >= 1; $exts_i--) { //To Get The Number of digits from starting of mobile number entered
			$search_qry.="prefix='" . substr($cntry, 0, $exts_i) . "' OR ";
		    }
		    $search_qry = substr($search_qry, 0, -4);
		    $search_qry = $search_qry. ")";
		    
		    //$search_qry="select distinct description,prefix,voice_rate from tariffs where  prefix like '".$cntry."%' and ";	
		    
		}
	}
	else 
	{	
		if(!is_numeric($cntry))
		{
//			echo "in 3";
			$search_qry="select distinct countryName,prefix,voiceRate,operator from 91_tariffs where countryName like '".$cntry."%' and tariffId like '8'  ";
			
		}
		else
		{
		//$search_qry="select distinct description,prefix,voice_rate from tariffs where  prefix like '".$cntry."%' and id_tariff like '8' ";
		
		$len_max=5;
		    $search_qry="select distinct countryName,prefix,voiceRate,operator from tariffs where tariffId like 8 and ( ";
		    for ($exts_i = $len_max; $exts_i >= 1; $exts_i--) { //To Get The Number of digits from starting of mobile number entered
			$search_qry.="prefix='" . substr($cntry, 0, $exts_i) . "' OR ";
		    }
		    $search_qry = substr($search_qry, 0, -4);
		    $search_qry = $search_qry. ")";
		    
		}
	}
//	$search_qry="select login from clientsshared where login like '".$q."%'";
//        echo $search_qry;
//        echo "zzz";
        
     
	$exe_qry=mysqli_query($dbh,$search_qry) or die(mysqli_error());
        
//	echo mysqli_num_rows($exe_qry);
	if(mysqli_num_rows($exe_qry)>0)
	{
	    
		$ct=0;
		while($res=mysqli_fetch_array($exe_qry))
		{
			//$arr = array ('id'=>'6','error'=>"Profile Updated Successfully ");
			//echo json_encode($arr);
			//exit();
			//echo $res['description']." (".$res['prefix'].") |".$res['description']."|".$res['prefix']."|".$res['voice_rate']."\n";
			
			
//			$descArray=  explode("-", $res['description']);
                    
                        #if action is not loadDetails then 1 oterwise 0 
			if($isDetail!=1)
			{
                            #item value is a country name 
			    $item=  trim($res['countryName']);
			    $final[]=$item;
			}
			else
			{
			    #operator name 
                            $operat = $res['operator'];
                            
                            #if operator name is not present then set country name as a operator 
                            if(!isset($res['operator']))
					$operat=$res['countryName'];
                                
                                
			    $desc = $operat;
			    $item[$desc]=$res['voiceRate'];
			    $final=$item;
			}

		}
	}
	else
	{
//            $item["lable"]="No result found.";
            $item["value"]="No result found.";
                        $final[]=$item;
//		echo "No result found.";
	}
	mysqli_close($dbh);
        
        if($isDetail==1)        
            $a= "";
        else
            $final=  array_values(array_unique($final));

        echo json_encode($final);
	//exit();
}

?>