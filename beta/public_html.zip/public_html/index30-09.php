<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Phone91 | Pc to phone calling | Internet to phone call</title>
<meta name="keywords" content="call computer to phone, Pc to Phone, Pc to Phone calling, Pc to mobile, Internet to phone call"/>
<meta name="description" content="Phone91 is the international phone calling service provider. Get quality VoIP calling service of pc to phone, Internet to phone call at affordable cost."/>
<?php include_once('includes/head.php')?>
</head>
<body>

<!--script for fb posts-->
<div id="fb-root"></div>
	<script>(function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
              fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
    </script> 

<?php include_once('includes/header.php')?>

<div class="bannerMainbg">
    <div class="innerBannerbg">
      <div class="getForm"> <img src="media/getdiscount.gif" width="273" height="30" alt="" title=""/>
	      <p class="registerNow"><span>Register now</span> and start making low cost international calls</p>
	      <form action="" method="" id="discountForm">
	        <span class="firstName">
	        <input type="text" id="" class="" placeholder="First Name" />
	        </span> <span class="email">
	        <input type="text" id="" class=""  placeholder="Email"/>
	        </span> <span class="password">
	        <input type="password" id="" class=""  placeholder="Password"/>
	        </span> <span class="clr"></span>
	        <input type="submit" title="Sign Up For Free" value="" />
	        <span class="belowTitle">By signing up, you agree to the Terns of Use abd Privacy Policy</span>
	      </form>
	    </div>
	    <div class="banner"> <img src="media/banner.jpg" width="537" height="303" alt="" title=""  /> </div>
       <span class="clr"></span> </div>
       </div>

<!--MainContainer-->
<div id="mainContainer">
  <div class="container"> <a href="#" class="howitworks" title="How it works?"></a>
    <h2 class="callRateshead">Call Rates</h2>
    <div class="callRates"> <span class="inputbgBig">
      <input type="text" id="" class="" value="" name="" placeholder="Type Country Name" />
      </span>
      <div class="flagsWrap"> <a href="#"> <img src="media/flag1.jpg" width="39" height="26" alt="" title="" /> <span>1.2¢/min</span> </a> <a href="#"> <img src="media/flag2.jpg" width="39" height="26" alt="" title="" /> <span>1.2¢/min</span> </a> <a href="#"> <img src="media/flag1.jpg" width="39" height="26" alt="" title="" /> <span>1.2¢/min</span> </a> </div>
      <span class="clr"></span> </div>
    <!--BottomContainer-->
    <div class="mrT4">
      <div class="box">
        <ul class="need">
          <li class="head">
            <h1>What you need to have?</h1>
          </li>
          <li>PC/Mobile.</li>
          <li>Headphones.</li>
        </ul>
        <ul class="need even">
          <li class="head">
            <h1>What you'll get?</h1>
          </li>
          <li>Unlimited international calling at local rates.</li>
          <li>Quick connectivity.</li>
          <li>And…a chance to surprise your family/friends sitting at a faraway place.</li>
        </ul>
      </div>
      <div class="box mid">
          <ul class="need pdL2">
          <li class="head mrB"><h1>Supported Dialers</h1></li>
          <li><a href="../integration.php#gtalk">Google Talk</a></li>
          <li><a href="../integration.php#nimbuzz">Nimbuzz</a></li>
          <li><a href="../integration.php#vtalk">iPhone By Vtok</a></li>
          <li><a href="javascript:;">Gtalk</a></li>
          <li><a href="javascript:;">Skype <span>(coming soon...)</span></a></li>
          <li><a href="javascript:;">msn <span>(coming soon...)</span></a></li>
          </ul>
      </div>
      <!--<div class="box mid">
        <h1>Supported Dialers</h1>
        <ul class="supported">
          <li><img src="media/talk.png" width="60" height="28" alt="" title="" /></li>
          <li><img src="media/nimbuzz.png"  width="82" height="25" alt="" title="" /></li>
          <li class="last"><img src="media/vtolk.png" width="57" height="37" alt="" title="" /></li>
        </ul>
      </div>-->
      <div class="box">
        <div class="fb">
          <div class="fb-like-box" data-href="http://www.facebook.com/phone91" data-width="300" data-show-faces="true" data-stream="true" data-header="true"></div>
        </div>
      </div>
      <span class="clr"></span></div>
    <!--//BottomContainer--> 
    <span class="clr"></span> </div>
</div>
<!--//MainContainer--> 

<?php include_once('includes/footer.php')?>

</body>
</html>
