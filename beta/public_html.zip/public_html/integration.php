<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Integration</title>
<?php include_once('includes/head.php')?>
<style type="text/css">
.cmndiv, .incmndiv { display:none; }
#leftCnt { width:160px; }
#rightCnt { margin: 20px 0 0 47px; width: 750px; }
#leftCnt ul.ln li { border-bottom:1px solid #E7E7E7; display: block; list-style-type: none; margin: auto; padding: 22px 0; position: relative; width: 160px; }
#leftCnt ul.ln { border-top: 1px solid #CCCCCC; display: block; float: left; margin: auto 0; padding: 0; position: relative; text-align: left; top: 30px; width: 160px; }
#rightCnt #htabs li { background: #F8F8F8; border-bottom-width: 0; float: left; color:#555555; list-style: none outside none; margin: 2px 0.2em 0 0; padding: 11px 19px; white-space: nowrap; font-size: 18px; padding: 0.5em 1em; border:1px solid #C2C2C2; border-bottom:0; text-decoration: none; }
#rightCnt #htabs li:hover, #rightCnt #htabs li.active { background:#37B7FF; color: #FFFFFF; }
.cmndiv #step, .cmndiv #video { border: 1px solid #CECECE; background:#F8F8F8; clear: both; padding: 2em 1.4em; }
#gtalk h1 { color: #333333; font-family: Segoe UI; font-size: 18px; font-style: normal; font-weight: normal; }
#gtalk h3 { color: #222222; font-size: 16px; font-style: italic; padding: 25px 0 10px; }
#gtalk p { color: #222222; font-size: 14px; padding-bottom: 5px; }
#gtalk span.stepsStart { clear: both; display: block; font-size: 13px; padding-bottom: 5px; }
</style>
</head>
<body class="innerPage">

	<!--Header-->
<?php include_once('includes/header.php')?>
	<!--heading-->
<h1 class="heading topHeader pdT3">Integrations</h1>

<!--MainContainer-->
<div id="mainContainer">
  <div class="container pdT4" id="innerPageContent">
    
    <div id="leftCnt" class="fl">
      <ul class="ln">
        <li class="home selected"><a href="#gtalk"><img src="media/tab_img1.png" width="94" height="45" alt="" title="" border="0" /></a></li>
        <li class="login"><a href="#nimbuzz"><img src="media/tab_img2.png" width="87" height="27" alt="" title="" border="0" /></a></li>
        <li class="support"><a href="#vtalk"><img src="media/tab_img3.png" width="89" height="58" alt="" title=""border="0"  /> </a></li>
      </ul>
    </div>
    <!--ul end here-->
    
    <div id="rightCnt" class="fl"><!--main right side div start from here-->
      
      <div class="cmndiv" id="gtalk">
        <div >
          <ul id="htabs" class="ln">
            <li class="fl crs cmnli active" for="step">Step by step</li>
            <li class="fl crs cmnli" for="video">Video</li>
          </ul>
          <div id="step" class="cmnshower">
            <h1> Staying connected with your near ones is now possible with Gtalk too. Use the below steps to enable VOIP calling with Gtalk. </h1>
            <h3>Step 1</h3>
            <p>Add <b>phone@phone91.com</b> to your <b>Gtalk contacts</b>, and you'll be able to see Phone 91 in your chat list. </p>
            <img src="media/gtalk_step1.png" width="231" height="440" alt="" title="" />
            <h3>Step 2</h3>
            <span class="stepsStart">Start chat with Phone 91, and type "Register &lt;username &gt; &lt;pssword&gt;" in the chat box. Use the username and password you had used during the Sign up process.</span> <img src="media/gtalk_step2.png" width="231" height="440" alt="" title="" />
            <h3>Step 3</h3>
            <span class="stepsStart">Now type the destination number that you want to dial along with the Country code.</span> <img src="media/gtalk_step3.png" width="231" height="440" alt="" title="" />
            <h3>Step 4</h3>
            <span class="stepsStart">Have a little patience and press the call button.And you are done! Start making calls to your family/friends right away.</span> <img src="media/gtalk_step4.png" width="231" height="440" alt="" title="" /> </div>
          <div id="video" class="incmndiv cmnshower">
            <p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
          </div>
        </div>
      </div>
      <div class="cmndiv" id="nimbuzz">
        <h4> Secure Login</h4>
      </div>
      <div class="cmndiv" id="vtalk">
        <h4> Online Support</h4>
        Maecenas in varius nulla. Morbi leo elit, volutpat ac faucibus in; aliquam eget
        massa. Nullam a neque ac turpis luctus venenatis et placerat risus. Quisque pretium
        scelerisque sapien, et accumsan nunc venenatis non. Donec ullamcorper, leo gravida
        hendrerit interdum, tellus nisi vestibulum justo; quis dignissim enim risus quis
        ipsum.<br />
        <br />
        Mauris fringilla, urna vitae posuere commodo, neque tellus tincidunt nisi, aliquam
        scelerisque purus nulla ac enim. Cras urna urna, vestibulum ut aliquam sed, laoreet
        et justo! Vestibulum eleifend porta mollis. Donec molestie, turpis sed commodo consequat,
        erat purus sollicitudin arcu, non vestibulum risus lacus ac ipsum. Curabitur vitae
        pellentesque purus. </div>
    </div>
    <span class="clr"></span> </div>
</div>
<!--//MainContainer--> 
<!--Footer-->
<?php include_once('includes/footer.php')?>
<!--//Footer--> 
<script>
function showDiv(){
	var val = window.location.hash.substring(1);
	console.log(val);
	
		$('html,body').animate({scrollTop: $("#logo").offset().top-140},'slow');
		$('.cmndiv').hide();
		$('#rightCnt #'+val).show();
		//$('.anibtn').removeClass('active');
		//$('.'+val).addClass('active');
	
}
$(document).ready(function() {
	if(window.location.hash){showDiv();}
	$(window).bind('hashchange',function(){showDiv();});
	
	$('.cmnli').click(function(){
		var inval =$(this).attr('for');
		
		$('.cmnshower').hide();
		$('#'+inval).show();
		
		$('.cmnli').removeClass('active');
		$(this).addClass('active');
	})
	
});


</script>
</body>
</html>
