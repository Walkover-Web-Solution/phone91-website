<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Android VoIP Calling | Enjoy low calling rates on Android Talk</title>
<meta name="keywords" content="Android VoIP Calling, Android cheap calling, Android Talk"/>
<meta name="description" content="Android users can make cheap calls using their android smart phone. All android users can use android talk for enjoying cheap calling rates of VoIP Technology"/>
<?php include_once('includes/head.php')?>
</head>
<body>
<style>html{background:none;}</style>
<?php include_once('includes/header.php')?>

<!--heading-->
<h1 class="heading topHeader pdT3">Android VoIP Calling</h1>

<!--MainContainer-->
<div id="mainContainer">
	<div class="container pdT4">
      
          <ul id="indul" class="ln">
                <li>
                      <div class="fl wid500">
                        <h4>Android talk</h4>
                        <p>Android is the word of the mouth today. Upgrade yourself to Android without fears. Accustomed to Gtalk? Need not worry; the <b><i>Android talk</i></b> brings in Gtalk in your hand! Access all your 
friends from your Android enabled cell phone which you just got. All features of Gtalk that you 
loved it for are available from Android talk.</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
                <li>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                      <div class="fl wid500">
                        <h4>Message It! </h4>
                        <p>Don't miss Gtalk; Android talk is at your service! You can still keep in touch with all your contacts through instant messaging like before. Android talk accesses your contact list directly 
from your Google account and pulls in all the names there. You can message your way out right 
from there. Does that bring smile to your face?</p>
                      </div>
                </li>
                
                <li>
                      <div class="fl wid500">
                        <h4>Get Professional</h4>
                        <p>Not interested in just instant messaging but professional video conferencing? <b><i>Android talk</i></b> is fit for you as well. One can call and have voice or video chat from the Android enabled hand held 
gizmo. All that you need is a front camera in that case. Plugin your head phones and start the 
conference without wasting any more minutes!</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
                <li>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                      <div class="fl wid500">
                        <h4>Privacy!</h4>
                        <p>Android takes care of your privacy very carefully and respects it. Change settings whenever you want! Android talk gives you the freedom to set the settings as per to your choice of privacy and 
et al. Set your status and change it as in Gtalk. Get visible by your wish and many such settings 
options are there just for your comfort!</p>
                      </div>
                </li>
                
          </ul>
      
      
      </div>
</div>
<!--//MainContainer--> 

<?php include_once('includes/footer.php')?>

</body>
</html>
