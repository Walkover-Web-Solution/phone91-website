<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pricing</title>
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<body class="innerPage">
<!--MainWrapper-->
<div id="mainWrapper">
  <div id="header"> 
    <!--Header-->
    <div class="topHeader"> <a href="index.php" id="logo" title=""></a>
      <div class="rightHeader">
        <div class="nav"> <a href="index.php">Home</a> 
	        <a href="integration.php#gtalk">Integration</a> 
	        <a href="pricing.php">Pricing</a> 
	        <a href="#" class="fbPadd"><img src="media/fbsignin.png" width="161" height="30" alt="" title=""/></a> 
        <span class="clr"></span> 
        </div>
        <span class="clr"></span>
        <div class="signinForm">
          <form action="" method="" id="signinForm">
            <span class="inputbg">
            <input type="text" id="" class="" name="" value=""  placeholder="Email"/>
            </span> <span class="inputbg">
            <input type="password" id="" class="" placeholder="Password"/>
            </span>
            <input type="submit" title="Sign in" id="" class="signin" />
            <span class="spanOr">Or</span>
            <input type="submit" title="Sign Up" id="" class="signup"  />
          </form>
        </div>
      </div>
      <span class="clr"></span> </div>
  </div>
  <!--//Header--> 
  
  <span class="clr"></span> </div>
<!--// MainWrapper--> 
<!--MainContainer-->
<div id="mainContainer">
  <div class="container" id="innerPageContent">
    <h1>Pricing</h1>
    
   
    
    
    <span class="clr"></span> 
  </div>
</div>
<!--//MainContainer--> 
<?php include_once ('includes/footer.php'); ?>