<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Use cheap calling cards to make cheap international calls anywhere!</title>
<meta name="keywords" content="cheap calling cards, international calling cards, calling cards, mobile calling rates, overseas calling rates"/>
<meta name="description" content="Cheap calling cards are used to make international calls at low rates. If you like chit chats and wants to talk timeless, than prepaid cards is perfect choice."/>
<?php include_once('includes/head.php')?>
</head>
<body>
<style>html{background:none;}</style>
<?php include_once('includes/header.php')?>

<!--heading-->
<h1 class="heading topHeader pdT3">Cheap calling cards</h1>

<!--MainContainer-->
<div id="mainContainer">
	<div class="container pdT4">
      
          <ul id="indul" class="ln">
                <li>
                      <div class="fl wid500">
                        <h4>Cheap calling cards</h4>
                        <p align="justify">Are you a present believer? <b><i>Cheap calling cards</i></b> are just for you! They are designed especially for people who don't give a damn about what will happen tomorrow. It gives you the liberty to 
choose your talk time before you kick start the phone call. You can actually pre-pay as per your 
budget so as to not to cry in order to pay the following long phone bill after the call.</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
                <li>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                      <div class="fl wid500">
                        <h4>Call Cheap! </h4>
                        <p align="justify">Calling cards is at your service to make international calling cheap! Yes cheap! You can now call places round the globe and talk as much as you want without the fear of long bills. There 
are many ways to cheap <b><i>international calling cards</i></b>, but Calling cards are not just cheap, but fast and 
convenient way of calling abroad! You can reach as many people as you want for as many 
numbers of times you want with cheap calling cards!</p>
                      </div>
                </li>
                
                <li>
                      <div class="fl wid500">
                        <h4>Minutes for credits!</h4>
                        <p align="justify"><b><i>Calling cards</i></b> can be used to redeem your 'on call time'. The pre paid calling card credits you minutes to stay on line according to the credit in your account! It is easy to use such calling 
cards for both students as well as business personals. Post paid calling cards give the freedom 
to speak as much as one wants. One can use prepaid calling cards if needed or can use post paid 
calling cards as per to their requirements.</p>
                      </div>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                </li>
                
                <li>
                      <div class="fl wid350"> <img src="media/blank.png"> </div>
                      <div class="fl wid500">
                        <h4>Forget local phone companies</h4>
                        <p align="justify">When you made phone calls using local phone companies you always had to think of distance before calling, isn't it? Whether the place located is rural or urban, if it's far or near. These 
factors needed to be considered because of its direct impact on the <b><i>mobile calling rates</i></b> of the call. After the 
launch of calling cards one can leave behind the local phone companies and stay tension free 
about all of it and just enjoy speaking over phone!</p>
                      </div>
                </li>
                
          </ul>
      
      
      </div>
</div>
<!--//MainContainer--> 

<?php include_once('includes/footer.php')?>

</body>
</html>
