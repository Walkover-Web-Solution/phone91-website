<?php
function countryArray() {
        $url = "http://voip92.com/isoData.php";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($ch);
        curl_close($ch);

        $string1 = json_decode($data, true);
        for ($i = 0; $i < count($string1); $i++) {
            $country[$string1[$i]['CountryCode']] = $string1[$i]['Country'];
        }
        return $country;
}
    
$country = countryArray();




?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sign Up</title>
<?php include_once('includes/head.php')?>

</head>
<body class="innerPage">

<!--Header-->
<?php include_once('includes/header.php')?>
<!--heading-->
<script type="text/javascript" src="js/jquery.form.js"></script> 
<script type="text/javascript" src="js/sign_up.js"></script>

<h1 class="heading topHeader pdT3">Sign Up</h1>

<!--MainContainer2572268-->
<div id="mainContainer">
  <div class="container pdT4" id="innerPageContent">
    <form name="signup" class="signup" id="signup" method="post" action="http://phone.phone91.com/action_layer.php?action=signup">
             <div class="fields">
                    <label>Choose Username:</label>
                   <input name="username" id="username" type="text"  onblur="check_user_exist(); return false;" onkeyup="check_user_exist()"/>
                   <div class="msg pa"></div>
             </div>
              
              <div class="fields">
                    <label>Choose your country:</label>
                    <select tabindex="1"  name="location" id="location" >
                    <?php 
                    foreach($country as $key =>$countryNames){                
                    echo "<option value='$key'>$countryNames</option>";
                    }?>    
                    
                    </select>
              </div>
              
               <div class="fields">
                    <label>Phone Number:</label>
                    <input name='code' type="text" id="code" onkeyup="selectOption($(this).val())" class="min"  />
                    <input type="text" name='mobileNumber' id='mobileNumber' class="max" />
                    
              </div>
              
               <div class="fields">
                    <label>Email:</label>
                    <input type="text" name='email' id='email' onkeyup="check_email_exist()" />
                    <div class="msg pa"></div>
              </div>
              
                <div class="fields">
                    <label>Choose Password:</label>
                   <input type="password" name='password' id='password' />
              </div>
              
               <div class="fields">
                    <label>Re-Enter Password:</label>
                   <input type="password" name='repassword' id='repassword' />
              </div>
              
              <div class="fields">
                    <label>Choose Currency:</label>
                    <select name="currency" id="currency">   
                   <option value="63">INR</option>
                    <?php                       
                    foreach ( $currencyArray as $key => $value) {

                    echo '<option value="'.$value["currencyId"].'" >'.$value["currency"].'</option>';
                    }
                       ?>
                    </select>
              </div>
              
               <div class="fields">
                    <label>User:</label>
                    <select name="client_type" id="client_type" >
            <option value="3" selected>User</option>
            <option value="2">Reseller</option>
        </select>
              </div>
              
               <div class="fields">
                    <label>&nbsp;</label>
                    <input type="submit" id="signupSubmit" title="Submit" value="Submit" onfocus="this.blur();"/>
   
               </div>
              
    </form>
    <span class="clr"></span> </div>
</div>
<!--//MainContainer--> 
<!--Footer-->
<?php include_once('includes/footer.php')?>
<!--//Footer-->
<script type="text/javascript">
	function showDiv(){
		var val = window.location.hash.substring(1);
		console.log(val);
		
			$('html,body').animate({scrollTop: $("#logo").offset().top-140},'slow');
			$('.cmndiv').hide();
			$('#rightCnt #'+val).show();
			//$('.anibtn').removeClass('active');
			//$('.'+val).addClass('active');
		
	}
	/*$(document).ready(function() {
		if(window.location.hash){showDiv();}
		$(window).bind('hashchange',function(){showDiv();});
		
		$('.cmnli').click(function(){
			var inval =$(this).attr('for');
			
			$('.cmnshower').hide();
			$('#'+inval).show();
			
			$('.cmnli').removeClass('active');
			$(this).addClass('active');
		})
		
	});
	*/
	</script>
</body>
</html>
