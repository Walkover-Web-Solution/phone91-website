<!--MainWrapper-->
<div id="mainWrapper">

  <div id="header"> 
    <!--Header-->
    <div class="topHeader"> <a href="index.php" id="logo" title=""></a>
          <div class="rightHeader">
        <div class="nav"> <a href="index.php">Home</a> <a href="integration.php#gtalk">Integration</a> <a href="#">Pricing</a> <!--<a href="#" class="fbPadd"><img src="media/fbsignin.png" width="161" height="30" alt="" title=""/></a>--> <span class="clr"></span> </div>
        <span class="clr"></span>
         <?php if(isset($_SESSION['error'])){
            echo $_SESSION['error'];
            session_destroy('error'); }?>
        
        <div class="signinForm">
             <form action="http://phone.phone91.com/action_layer.php?action=loginRedirect" method="POST" name="login"><!--http://phone.phone91.com/action_layer.php?action=loginRedirect-->
            <span class="inputbg">
                 <input type="text" name="uname" placeholder="Username"
                                onfocus="(this.value == 'Username') && (this.value = '')"
                                onblur="(this.value == '') && (this.value = 'Username')" id="" class="" value=""/>
                </span> <span class="inputbg">
                <input type="password" name="pwd" placeholder="Password"
                                onfocus="(this.value == 'Passaword') && (this.value = '')"
                                onblur="(this.value == '') && (this.value = 'Passaword')" id="" class=""/>
                </span>
                 <input type="hidden" name="domain" id="domain" value="<?php echo "http://".$_SERVER['HTTP_HOST'];?>"/>
               <input type="submit" title="Sign In" name="submit" id="" class="signin"/>  
            <span class="spanOr">Or</span>
            <input type="button" title="Sign Up" id="" class="signup"  onclick="window.location='/signup.php';"/>
          </form>
            </div>
      </div>
          <span class="clr"></span> </div>    
    </div>
  <!--//Header--> 
  <span class="clr"></span> </div>
<!--// MainWrapper--> 