<!--Footer-->
<div id="footer" style="z-index:999999;">
  <div class="innerFooter">
    <ul>
      <li class="fHead">About us</li>
      <li><a href="voipreseller.php">VoIP Reseller</a></li>
      <li><a href="androidvoipcalling.php">Android VoIP Calling</a></li>
      <li><a href="callingoverseas.php">Calling Overseas</a></li>
      <li><a href="cheapcallingcards.php">Cheap calling cards</a></li>
      <li><a href="fring.php">Fring Calls</a></li>
      <li><a href="gmail.php">Gmail-VoIP</a></li>
    </ul>
    <ul>
      <li class="fHead">More features</li>
      <li><a href="gtalk-voip.php">Gtalk-VoIP</a></li>
      <li><a href="internationalcall.php">International call</a></li>      
      <li><a href="voipmobiledialer.php">Mobile dialer</a></li>
      <li><a href="nimbuzz.php">Nimbuzz</a></li>
      <li><a href="phonecall.php">Phone Call</a></li>
      <li><a href="sipcall.php">Sip call</a></li>
      <li><a href="voipcall.php">VoIP call</a></li>
    </ul>
    <ul>
      <li class="fHead">Address</li>
      <li><p>Walkover Web Solutions UK Limited 145-157 St John Street, London - EC1V 4PY, England, UK</p></li>
      
     <li> <a href="http://startups.livechatinc.com"> <img src="http://cdn.livechatinc.com/startups/livechat-for-startups@2x.png" width="96" height="72" alt="LiveChat for Startups"></a> </li>
     
    </ul>
    <span class="clr height"></span>
   </div>
</div>
<!--//Footer--> 
<script>
function showDiv(){
	var val = window.location.hash.substring(1);
	console.log(val);
	
		$('html,body').animate({scrollTop: $("#logo").offset().top-140},'slow');
		$('.cmndiv').hide();
		$('#rightCnt #'+val).show();
		//$('.anibtn').removeClass('active');
		//$('.'+val).addClass('active');
	
}
$(document).ready(function() {
	if(window.location.hash){showDiv();}
	$(window).bind('hashchange',function(){showDiv();});
	
	$('.cmnli').click(function(){
		var inval =$(this).attr('for');
		
		$('.cmnshower').hide();
		$('#'+inval).show();
		
		$('.cmnli').removeClass('active');
		$(this).addClass('active');
	})
	
});


</script>
<!-- start shubhendra live chat -->
<script type="text/javascript">
var __lc = {};
__lc.license = 3598901;

(function() {
	var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
	lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
<!-- end shubhendra live chat -->

</body>
</html>